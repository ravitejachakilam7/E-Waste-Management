package com.ewate.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ewate.model.Ewaste;

@Repository
public interface EwasteRepository extends CrudRepository<Ewaste, String>{

	Optional<Ewaste> findTopByOrderByIdDesc();

	Optional<Ewaste> findByEwasteId(String ewasteid);

	Optional<List<Ewaste>> findBySellerId(String string);

	Optional<List<Ewaste>> findAllBySellerId(String string);

	Optional<List<Ewaste>> findAllByStatus(String string);

	Optional<List<Ewaste>> findAllBySellerIdAndStatus(String uid, String string);

}
