package com.ewate.repository;
import java.util.List;
import java.util.Optional;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.ewate.model.Application;
import com.ewate.model.Ewaste;

@Repository
public interface ApplicationRepository extends CrudRepository<Application, String>{

	Optional<Application> findTopByOrderByIdDesc();

	Optional<Application> findByAppId(String string);

	Optional<List<Application>> findAllByBuyerId(String string);

	Optional<List<Application>> findAllByEwasteId(String reqId);

	Optional<Application> findByEwasteId(String reqId);

	Optional<Application> findTopByOrderByEwasteIdDesc(String reqId);

	Optional<List<Ewaste>> findAllBySellerId(String string);

	List<Application> findByStatusAndEwasteId(String string, String ewasteId);

}
