package com.ewate.controller;

import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ewate.model.Buyer;
import com.ewate.model.Login;
import com.ewate.model.Seller;
import com.ewate.repository.BuyerRepository;
import com.ewate.repository.PaymentRepository;
import com.ewate.repository.SellerRepository;

@RequestMapping("/account")
@Controller
public class AccountController {

	@Autowired
	BuyerRepository buyerRepo;
	
	@Autowired
	SellerRepository sellerRepo;

	@RequestMapping()
    public String login(Model model) {
        return "login";
    }	
	
	@RequestMapping("/admin_login")
    public String adminLogin() {
        return "admin_login";
    }
	@RequestMapping("/seller_login")
    public String sellerLogin() {
        return "seller_login";
    }
	@RequestMapping("/buyer_login")
    public String buyerLogin() {
        return "buyer_login";
    }
	
	@PostMapping("/login/buyer")
	public String buyerLogin(Login login, Model model, HttpServletRequest request) {
		Optional<Buyer> obj = buyerRepo.findByEmailIdAndPassword(login.getEmail(),login.getPassword());
		if(obj.isPresent())
		{
			model.addAttribute("name",obj.get().getName());
			request.getSession().setAttribute("id", obj.get().getId());
			request.getSession().setAttribute("userid", obj.get().getBuyerId());
			request.getSession().setAttribute("usertype", "buyer");
			request.getSession().setAttribute("name", obj.get().getName());
			return "redirect:/buyer/home";
		}
		else
		{
			model.addAttribute("buyermsg","Invalid Login Credentials");
			return "/buyer_login";
		}
	}

	@PostMapping("/login/seller")
	public String sellerLogin(Login login, Model model, HttpServletRequest request) {
		Optional<Seller> obj = sellerRepo.findByEmailIdAndPassword(login.getEmail(),login.getPassword());
		if(obj.isPresent())
		{
			model.addAttribute("name",obj.get().getName());
			request.getSession().setAttribute("id", obj.get().getId());
			request.getSession().setAttribute("userid", obj.get().getSellerId());
			request.getSession().setAttribute("usertype", "seller");
			request.getSession().setAttribute("name", obj.get().getName());
			return "redirect:/seller/home";
		}
		else
		{
			model.addAttribute("sellermsg","Invalid Login Credentials");
			return "/seller_login";
		}
	}
	

	@PostMapping("/login/admin")
	public String adminLogin(Login login, Model model, HttpServletRequest request) {
		if(login.getEmail().equals("admin") && login.getPassword().equals("admin"))
		{
			model.addAttribute("name","Admin");
			request.getSession().setAttribute("id", "Admin");
			request.getSession().setAttribute("userid", "Admin");
			request.getSession().setAttribute("usertype", "admin");
			request.getSession().setAttribute("name", "Admin");
			return "redirect:/account/home";
		}
		else
		{
			model.addAttribute("adminmsg","Invalid Login Credentials");
			return "/admin_login";
		}
	}
	

	@RequestMapping("/home")
    public String home(Model model, HttpServletRequest req) {
		return "admin_home";
    }
	
	@RequestMapping("/logout")
    public String logout(Model model, HttpServletRequest req) {
        req.getSession().invalidate();
        return "logout";
    }
	
	    
}
