package com.ewate.controller;

import java.io.IOException;
import java.text.ParseException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ewate.model.Ewaste;
import com.ewate.model.Payment;
import com.ewate.repository.EwasteRepository;
import com.ewate.repository.PaymentRepository;

@RequestMapping("/booking")
@Controller
public class BookingController {

	@Autowired
	EwasteRepository ewasteRepo;

	@Autowired
	PaymentRepository payRepo;


	@RequestMapping("/list")
	public String bookingList(Model model, HttpServletRequest req) {
		String utype = req.getSession().getAttribute("usertype").toString();
		String uid = req.getSession().getAttribute("userid").toString();
		if (utype.equals("buyer"))
			model.addAttribute("datalist", payRepo.findAllByBuyerIdAndStatusEquals(uid,"Booked").get());
		else if (utype.equals("seller"))
			model.addAttribute("datalist", payRepo.findAllBySellerIdAndStatusEquals(uid,"Booked").get());
		else
			model.addAttribute("datalist", payRepo.findAllByStatus("Booked").get());

		return "booking_list";
	}

	@RequestMapping("/create/{id}")
	public String create(@PathVariable String id, Model model, HttpServletRequest request) {
		model.addAttribute("ewaste", ewasteRepo.findById(id).get());
		return "booking_create";
	}

	@RequestMapping("/save")
	public String saveBooking(@RequestParam String ewasteId, @RequestParam double amount, @RequestParam String payMode,
			HttpServletRequest req) throws IOException {
		Optional<Payment> idobj = payRepo.findTopByOrderByIdDesc();
		String id = null;
		if (idobj.isPresent()) {
			int idnum = Integer.parseInt(idobj.get().getPaymentId().substring(5));
			idnum++;
			id = "BOOK3" + idnum;
		} else {
			id = "BOOK362353";
		}

		Ewaste ewaste = ewasteRepo.findByEwasteId(ewasteId).get();

		Payment obj = new Payment();
		obj.setPaymentId(id);
		obj.setEwasteId(ewasteId);
		obj.setSellerId(ewaste.getSellerId());
		obj.setBuyerId(req.getSession().getAttribute("userid").toString());
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		obj.setPmtDate(LocalDateTime.now().toString());
		obj.setAmount(amount);
		obj.setPmtMode(payMode);
		obj.setStatus("Paid");
		payRepo.save(obj);

		ewaste.setStatus("SOLD");
		ewasteRepo.save(ewaste);

	
		return "redirect:/booking/list";
	}


	static String ymd_dmy(String date) throws ParseException {
		String arr[] = date.split("-");
		return arr[2] + "-" + arr[1] + "-" + arr[0];
	}
}
