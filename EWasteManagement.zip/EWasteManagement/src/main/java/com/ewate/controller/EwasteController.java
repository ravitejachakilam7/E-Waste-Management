package com.ewate.controller;

import java.io.IOException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.ewate.model.Application;
import com.ewate.model.Ewaste;
import com.ewate.model.Payment;
import com.ewate.repository.ApplicationRepository;
import com.ewate.repository.EwasteRepository;
import com.ewate.repository.PaymentRepository;
import com.ewate.service.FileUploadUtil;

@RequestMapping("/ewaste")
@Controller
public class EwasteController {

	@Autowired
	EwasteRepository repo;

	@Autowired
	ApplicationRepository appRepo;
	
	@Autowired
	PaymentRepository payRepo;

	@RequestMapping("/list")
	public String home(Model model, HttpServletRequest req) {
		if (req.getSession().getAttribute("usertype").equals("admin"))
			model.addAttribute("datalist", repo.findAll());
		else
			model.addAttribute("datalist", repo.findBySellerId(req.getSession().getAttribute("userid").toString()).get());
		
		System.out.println(repo.findAll());
		return "ewaste";
	}

	@RequestMapping("/create")
	public String create(Model model, HttpServletRequest request) {
		return "ewaste_create";
	}

	@RequestMapping("/save")
	public String save(Ewaste obj, @RequestParam("image") MultipartFile multipartFile, HttpServletRequest req) throws IOException{
		Optional<Ewaste> idobj = repo.findTopByOrderByIdDesc();
		String id = null;
		if(idobj.isPresent())
		{
			int idnum = Integer.parseInt(idobj.get().getEwasteId().substring(5));
			idnum++;
			id = "EWAST"+idnum;
		}
		else
		{
			id = "EWAST62353";
		}
		
		String imgUrl = id+multipartFile.getOriginalFilename();
		obj.setEwasteId(id);
		obj.setSellerId(req.getSession().getAttribute("userid").toString());
		obj.setStatus("Available");
		
		obj.setImgUrl(imgUrl);
		
		repo.save(obj);		
		
		String uploadDir = "uploads";
        
        FileUploadUtil.saveFile(uploadDir, imgUrl, multipartFile);
		return "redirect:/ewaste/list";
	}

	@RequestMapping("/details/{id}")
	public String Details(@PathVariable String id, Model model, HttpServletRequest request) {
		String ewasteid = repo.findById(id).get().getEwasteId();
		if(payRepo.findByEwasteId(ewasteid).isPresent())
			model.addAttribute("pmt", payRepo.findByEwasteId(ewasteid).get());
		else
			model.addAttribute("pmt", null);
		model.addAttribute("obj", repo.findById(id).get());
		model.addAttribute("applist", appRepo.findAllByEwasteId(repo.findById(id).get().getEwasteId()).get());
		return "ewaste_details";
	}

	@RequestMapping("/detail/{id}")
	public String Detail(@PathVariable String id, Model model, HttpServletRequest req) {
		if(payRepo.findByEwasteId(id).isPresent())
			model.addAttribute("pmt", payRepo.findByEwasteId(id).get());
		else
			model.addAttribute("pmt", null);

		model.addAttribute("obj", repo.findByEwasteId(id).get());
		model.addAttribute("applist", appRepo.findAllByEwasteId(id).get());
		return "ewaste_details";
	}
	
	@RequestMapping("/show/{id}")
	public String show(@PathVariable String id, Model model, HttpServletRequest request) {
		model.addAttribute("obj", repo.findById(id).get());
		return "ewaste_show";
	}

	@RequestMapping("/delete")
	public String delete(@RequestParam String id) {
		Optional<Ewaste> obj = repo.findById(id);
		repo.delete(obj.get());

		return "redirect:/ewaste/list";
	}

	@RequestMapping("/edit/{id}")
	public String edit(@PathVariable String id, Model model) {
		model.addAttribute("obj", repo.findById(id).get());
		return "ewaste_edit";
	}

	@RequestMapping("/update")
	public String update(Ewaste obj) {
		
		if(obj.getServiceCharge() != 0)
		{
			obj.setTotalAmount(obj.getQuotedAmount()+obj.getServiceCharge());
			obj.setStatus("Approved");
		}
		repo.save(obj);
		return "redirect:/ewaste/show/" + obj.getId();
	}
	
	@RequestMapping("/admin/update")
	public String adminUpdate(@RequestParam String id, @RequestParam double serviceCharge) {
		Ewaste ewaste = repo.findById(id).get();
		ewaste.setServiceCharge(serviceCharge);
		ewaste.setTotalAmount(serviceCharge + ewaste.getQuotedAmount());
		repo.save(ewaste);
		return "redirect:/ewaste/show/" + id;
	}
	

	@RequestMapping("/sold/{ewasteId}/{buyerId}")
	public String empUpdate(@PathVariable String ewasteId, @PathVariable String buyerId) {
		Ewaste ewaste = repo.findByEwasteId(ewasteId).get();
		ewaste.setBuyerId(buyerId);
		ewaste.setStatus("SOLD");
		repo.save(ewaste);
		
		Optional<Payment> idobj = payRepo.findTopByOrderByIdDesc();
		String id = null;
		if (idobj.isPresent()) {
			int idnum = Integer.parseInt(idobj.get().getPaymentId().substring(5));
			idnum++;
			id = "PMT65" + idnum;
		} else {
			id = "PMT6562353";
		}
		
		Payment obj = new Payment();
		obj.setPaymentId(id);
		obj.setEwasteId(ewasteId);
		obj.setSellerId(ewaste.getSellerId());
		obj.setBuyerId(buyerId);
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		obj.setPmtDate(LocalDateTime.now().toString());
		obj.setAmount(ewaste.getTotalAmount());
		payRepo.save(obj);

		return "redirect:/ewaste/payment/"+id;

//		
//		Payment payment = payRepo.findByEwasteId(ewasteId).get();
//		payment.setStatus("SOLD");
//		payRepo.save(payment);
//		return "redirect:/ewaste/detail/"+ewasteId;
	}

	@RequestMapping("/payment/{id}")
	public String payment(@PathVariable String id, Model model) {
		model.addAttribute("obj", payRepo.findByPaymentId(id).get());
		return "ewaste_payment";
	}
	
	@RequestMapping("/payment/update")
	public String paymentUpdate(@RequestParam String appId,@RequestParam String pmtMode) {
		Application application = appRepo.findByAppId(appId).get();
		Ewaste ewaste = repo.findByEwasteId(application.getEwasteId()).get();
		Optional<Payment> idobj = payRepo.findTopByOrderByIdDesc();
		String id2 = null;
		if (idobj.isPresent()) {
			int idnum = Integer.parseInt(idobj.get().getPaymentId().substring(5));
			idnum++;
			id2 = "PMT65" + idnum;
		} else {
			id2 = "PMT6562353";
		}
		
		Payment obj = new Payment();
		obj.setPaymentId(id2);
		obj.setEwasteId(ewaste.getEwasteId());
		obj.setSellerId(ewaste.getSellerId());
		obj.setBuyerId(application.getBuyerId());
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		obj.setPmtDate(LocalDateTime.now().toString());
		obj.setAmount(ewaste.getTotalAmount());
		obj.setPmtMode(pmtMode);
		obj.setStatus("paid");
		payRepo.save(obj);
		application.setStatus("paid");
		appRepo.save(application);
		return "setpaymentSuccess";
	}
		
	@RequestMapping("/sold")
	public String soldList(Model model, HttpServletRequest req) {
		String utype = req.getSession().getAttribute("usertype").toString();
		String uid = req.getSession().getAttribute("userid").toString();
		
		if (utype.equals("seller"))
			model.addAttribute("datalist", payRepo.findAllBySellerIdAndStatus(uid,"SOLD").get());
		else
			model.addAttribute("datalist", payRepo.findAllByStatus("SOLD").get());

		return "sold_list";
	}
	
	@RequestMapping("/setpayment/{id}")
    public String setpayment(@PathVariable String id,Model model) {
		System.out.println(id);
		model.addAttribute("appId", id);
		Application application = appRepo.findByAppId(id).get();
		Ewaste ewaste = repo.findByEwasteId(application.getEwasteId()).get();
		model.addAttribute("ewaste", ewaste);
		model.addAttribute("application", application);
        return "setpayment";
    }

}
