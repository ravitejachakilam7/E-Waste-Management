package com.ewate.controller;

import java.util.Iterator;
import java.util.List;
import java.util.Optional;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ewate.model.Application;
import com.ewate.model.Ewaste;
import com.ewate.repository.ApplicationRepository;
import com.ewate.repository.EwasteRepository;
import com.ewate.repository.SellerRepository;

@RequestMapping("/application")
@Controller
public class ApplicationController {

	@Autowired
	ApplicationRepository repo;

	@Autowired
	EwasteRepository ewasteRepo;
	
	
	
	@RequestMapping("/list/buyer")
    public String listtrans(Model model, HttpServletRequest req) {
//        model.addAttribute("datalist", repo.findAllByBuyerId(req.getSession().getAttribute("userid").toString()).get());
//        return "application_trans";
		return "redirect:/application/list";
	}

	@RequestMapping("/list")
    public String list(Model model, HttpServletRequest req) {
		if(req.getSession().getAttribute("usertype").equals("buyer"))
        model.addAttribute("datalist", repo.findAllByBuyerId(req.getSession().getAttribute("userid").toString()).get());

        model.addAttribute("datalist", repo.findAll());
        return "application";
    }

	@RequestMapping("/save")
	public String save(@RequestParam String ewasteId,@RequestParam String msg, HttpServletRequest request ){
		
		Optional<Application> idobj = repo.findTopByOrderByIdDesc();
		String id = null;
		if(idobj.isPresent())
		{
			int idnum = Integer.parseInt(idobj.get().getAppId().substring(5));
			idnum++;
			id = "APPL0"+idnum;
		}
		else
		{
			id = "APPL064901";
		}
		Application obj = new Application();
		obj.setAppId(id);
		obj.setEwasteId(ewasteId);
		obj.setMessage(msg);
		obj.setSellerId(ewasteRepo.findByEwasteId(ewasteId).get().getSellerId());
		obj.setBuyerId(request.getSession().getAttribute("userid").toString());
		obj.setStatus("Requested");
		repo.save(obj);		
		System.out.println(obj);
		return "redirect:/application/list";
	}
	
	@RequestMapping("/accept/{appId}")
	public String approve(@PathVariable String appId, Model model) {
		Application app = repo.findByAppId(appId).get();
		app.setStatus("Accepted");
		repo.save(app);
		
		Ewaste req = ewasteRepo.findByEwasteId(app.getEwasteId()).get();
		req.setStatus("Accepted");
		ewasteRepo.save(req);
		List<Application> apps = repo.findByStatusAndEwasteId("Requested",req.getEwasteId());
		Iterator<Application> appsIterator = apps.iterator();
		while (appsIterator.hasNext()) {
			Application application = (Application) appsIterator.next();
			application.setStatus("Rejected");
			repo.save(application);
		}
		return "redirect:/ewaste/detail/"+ app.getEwasteId();
	}
	
	
}
