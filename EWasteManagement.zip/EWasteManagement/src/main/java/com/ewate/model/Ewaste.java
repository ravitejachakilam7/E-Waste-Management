package com.ewate.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "ewaste")
public class Ewaste {
	
	@Id
	String id;
	String ewasteId;
	String sellerId;
	String buyerId;
	String imgUrl;
	int qty;
	String description;
	double quotedAmount;
	double serviceCharge;
	double totalAmount;
	String status;
	
	public Ewaste() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Ewaste(String id, String ewasteId, String sellerId, String buyerId, String imgUrl, int qty,
			String description, double quotedAmount, double serviceCharge, double totalAmount, String status) {
		super();
		this.id = id;
		this.ewasteId = ewasteId;
		this.sellerId = sellerId;
		this.buyerId = buyerId;
		this.imgUrl = imgUrl;
		this.qty = qty;
		this.description = description;
		this.quotedAmount = quotedAmount;
		this.serviceCharge = serviceCharge;
		this.totalAmount = totalAmount;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Ewaste [id=" + id + ", ewasteId=" + ewasteId + ", sellerId=" + sellerId + ", buyerId=" + buyerId
				+ ", imgUrl=" + imgUrl + ", qty=" + qty + ", description=" + description + ", quotedAmount="
				+ quotedAmount + ", serviceCharge=" + serviceCharge + ", totalAmount=" + totalAmount + ", status="
				+ status + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getEwasteId() {
		return ewasteId;
	}

	public void setEwasteId(String ewasteId) {
		this.ewasteId = ewasteId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getImgUrl() {
		return imgUrl;
	}

	public void setImgUrl(String imgUrl) {
		this.imgUrl = imgUrl;
	}

	public int getQty() {
		return qty;
	}

	public void setQty(int qty) {
		this.qty = qty;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public double getQuotedAmount() {
		return quotedAmount;
	}

	public void setQuotedAmount(double quotedAmount) {
		this.quotedAmount = quotedAmount;
	}

	public double getServiceCharge() {
		return serviceCharge;
	}

	public void setServiceCharge(double serviceCharge) {
		this.serviceCharge = serviceCharge;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}


}
