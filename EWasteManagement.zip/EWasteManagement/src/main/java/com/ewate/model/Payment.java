package com.ewate.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "payment")
public class Payment {
	
	@Id
	String id;
	String paymentId;
	String ewasteId;
	String sellerId;
	String buyerId;
	String pmtDate;
	double amount;
	String pmtMode;
	String status;

	public Payment() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Payment(String id, String paymentId, String ewasteId, String sellerId, String buyerId, String pmtDate,
			double amount, String pmtMode, String status) {
		super();
		this.id = id;
		this.paymentId = paymentId;
		this.ewasteId = ewasteId;
		this.sellerId = sellerId;
		this.buyerId = buyerId;
		this.pmtDate = pmtDate;
		this.amount = amount;
		this.pmtMode = pmtMode;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Payment [id=" + id + ", paymentId=" + paymentId + ", ewasteId=" + ewasteId + ", sellerId=" + sellerId
				+ ", buyerId=" + buyerId + ", pmtDate=" + pmtDate + ", amount=" + amount + ", pmtMode=" + pmtMode
				+ ", status=" + status + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPaymentId() {
		return paymentId;
	}

	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}

	public String getEwasteId() {
		return ewasteId;
	}

	public void setEwasteId(String ewasteId) {
		this.ewasteId = ewasteId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getPmtDate() {
		return pmtDate;
	}

	public void setPmtDate(String pmtDate) {
		this.pmtDate = pmtDate;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getPmtMode() {
		return pmtMode;
	}

	public void setPmtMode(String pmtMode) {
		this.pmtMode = pmtMode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	
}
