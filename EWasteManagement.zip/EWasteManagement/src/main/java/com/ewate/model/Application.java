package com.ewate.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "application")
public class Application {
	
	@Id
	String id;
	String appId;
	String ewasteId;
	String buyerId;
	String sellerId;
	String message;
	String status;

	public Application() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Application(String id, String appId, String ewasteId, String buyerId, String sellerId, String message,
			String status) {
		super();
		this.id = id;
		this.appId = appId;
		this.ewasteId = ewasteId;
		this.buyerId = buyerId;
		this.sellerId = sellerId;
		this.message = message;
		this.status = status;
	}

	@Override
	public String toString() {
		return "Application [id=" + id + ", appId=" + appId + ", ewasteId=" + ewasteId + ", buyerId=" + buyerId
				+ ", sellerId=" + sellerId + ", message=" + message + ", status=" + status + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getEwasteId() {
		return ewasteId;
	}

	public void setEwasteId(String ewasteId) {
		this.ewasteId = ewasteId;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
